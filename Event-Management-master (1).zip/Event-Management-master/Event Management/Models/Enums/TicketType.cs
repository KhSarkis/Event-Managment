﻿namespace Event_Management.Models.Enums
{
    public enum TicketType
    {
        BASIC = 1,
        VIP = 2,
        EARLYBIRD = 3
    }
}
