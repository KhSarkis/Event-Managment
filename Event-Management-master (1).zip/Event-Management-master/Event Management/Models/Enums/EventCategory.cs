﻿namespace Event_Management.Models.Enums
{
    public enum EventCategory
    {
        IT_And_Technologies = 1,
        Bussiness_Meetings = 2,
        Casual_Meetings = 3,
        Conferences = 4,
        Music = 5,
        Festivals = 6,
        Sports = 7,
        Fashion = 8,
        Startups_And_Product_Launches = 9
    }
}
