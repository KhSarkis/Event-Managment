﻿namespace Event_Management.Models.Enums
{
    public enum UserType
    {
        BASIC = 1,
        ARTIST = 2,
        SPEAKER = 3
    }
}
