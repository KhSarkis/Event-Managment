﻿namespace Event_Management.Models.Enums
{
    public enum PromoCodeStatus
    {
        Available = 1,
        OutOfStock = 2
    }
}
