﻿namespace Event_Management.Models.Enums
{
    public enum TicketStatus
    {
        AVAILABLE = 1,
        SOLD_OUT = 2,
        CANCELED = 3
    }
}
