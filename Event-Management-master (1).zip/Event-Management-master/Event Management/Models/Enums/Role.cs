﻿namespace Event_Management.Models.Enums
{
    public enum Role
    {
        BASIC = 1,
        PARTICIPANT = 2,
        ORGANIZER = 3,
        ADMINISTRATOR = 4
    }
}
