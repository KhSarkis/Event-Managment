﻿namespace Event_Management.Models.Enums
{
    public enum PurchaseStatus
    {
        PENDING = 1,
        COMPLETED = 2,
        REFUNDED = 3
    }
}
