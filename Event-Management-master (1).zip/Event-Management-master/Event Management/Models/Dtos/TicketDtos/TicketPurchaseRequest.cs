﻿namespace Event_Management.Models.Dtos.TicketDtos
{
    public class TicketPurchaseRequest
    {
        public int TicketId { get; set; }
        public int Quantity { get; set; }
    }
}
