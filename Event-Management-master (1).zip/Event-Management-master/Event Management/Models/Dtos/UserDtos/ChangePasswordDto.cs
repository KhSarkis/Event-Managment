﻿namespace Event_Management.Models.Dtos.UserDtos
{
    public class ChangePasswordDto
    {
        public string Password { get; set; }

        public ChangePasswordDto()
        {
            
        }
    }
}
