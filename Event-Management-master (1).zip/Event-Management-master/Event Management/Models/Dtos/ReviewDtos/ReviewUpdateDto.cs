﻿namespace Event_Management.Models.Dtos.ReviewDtos
{
    public class ReviewUpdateDto
    {
        public int StarCount { get; set; }
    }
}
