﻿namespace Event_Management.Models.Dtos.CommentDtos
{
    public class CommentUpdateDto
    {
        public string CommentContent { get; set; }
    }
}
