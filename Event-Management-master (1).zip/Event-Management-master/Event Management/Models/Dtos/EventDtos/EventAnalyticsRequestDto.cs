﻿namespace Event_Management.Models.Dtos.EventDtos
{
    public class EventAnalyticsRequestDto
    {
        public int OrganizerId { get; set; }
        public int EventId { get; set; }
    }
}
