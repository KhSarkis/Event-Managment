﻿namespace Event_Management.Models.Dtos.EventDtos
{
    public class RescheduleEventDto
    {
        public DateTime NewDate { get; set; }
    }
}
