﻿namespace Event_Management.Models.Dtos.ParticipantDtos
{
    public class ParticipantUpdateDto
    {
        public bool? Attendance { get; set; }

        public ParticipantUpdateDto()
        {
            
        }
    }
}
