﻿using Microsoft.AspNetCore.SignalR;

namespace Event_Management.Web_Sockets
{
    public class ParticipantHub : Hub
    {
    }
}
