﻿using Event_Management.Models.Dtos.UserDtos;
using Event_Management.Models.Enums;
using FluentValidation;

namespace Event_Management.Validations.UserValidations
{
    public class UserCreateDtoValidator : AbstractValidator<UserCreateDto>
    {
        public UserCreateDtoValidator()
        {
            RuleFor(x => x.Name)
                .NotEmpty().WithMessage("Name is required.")
                .MaximumLength(100).WithMessage("Name cannot exceed 100 characters.")
                .Matches(@"^[a-zA-Z\s]+$").WithMessage("Name can only contain alphabets and spaces."); ;

            RuleFor(x => x.Email)
                .NotEmpty().WithMessage("Email is required.")
                .EmailAddress().WithMessage("Invalid email format.");

            RuleFor(x => x.PhoneNumber)
                .NotEmpty().WithMessage("Phone number is required.")
                .Matches(@"^\+?[1-9]\d{1,14}$").WithMessage("Invalid phone number format.");

            RuleFor(x => x.Password)
                .NotEmpty().WithMessage("Password is required.")
                .MinimumLength(8).WithMessage("Password must be at least 8 characters long.")
                .Matches(@"[A-Z]").WithMessage("Password must contain at least one uppercase letter.")
                .Matches(@"[a-z]").WithMessage("Password must contain at least one lowercase letter.")
                .Matches(@"\d").WithMessage("Password must contain at least one number.")
                .Matches(@"[\W_]").WithMessage("Password must contain at least one special character.");

            RuleFor(x => x.EmailCode)
                .Length(6).WithMessage("Email verification code must be 6 characters.")
                .Matches("^[0-9]{6}$").WithMessage("Email verification code must contain only numbers.");

            RuleFor(x => x.PhoneNumberCode)
                .Length(6).WithMessage("SMS verification code must be 6 characters.")
                .Matches("^[0-9]{6}$").WithMessage("SMS verification code must contain only numbers.");
        }
    }
}
